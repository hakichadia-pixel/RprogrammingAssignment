# ==============================================================================
# COMPREHENSIVE GGPLOT2 GUIDE: AIRQUALITY DATASET (DARK THEME)
# ==============================================================================
# Description: This script covers all 13 specified ggplot2 geom and annotation 
# functions using the built-in `airquality` dataset (New York air quality measurements).
# Theme: Custom Dark Theme with high-contrast, vibrant color palettes.
# ==============================================================================

# 1. Load Required Libraries
library(ggplot2)
library(dplyr)

# 2. Prepare and Clean Data
# Convert Month to a factor for categorical grouping and clean missing values where needed
df_air <- airquality %>%
  mutate(
    Month_Factor = factor(Month, 
                          levels = 5:9, 
                          labels = c("May", "June", "July", "August", "September")),
    Day_Index = row_number() # Sequential day index for time-series style plots
  )

# 3. Define a Custom Dark Theme
# A sleek dark background with legible white/light-gray text and subtle gridlines
theme_dark_custom <- theme_dark() +
  theme(
    plot.background = element_rect(fill = "#1a1a1a", color = NA),
    panel.background = element_rect(fill = "#121212", color = NA),
    panel.grid.major = element_line(color = "#2c2c2c", linewidth = 0.5),
    panel.grid.minor = element_line(color = "#1f1f1f", linewidth = 0.25),
    text = element_text(color = "#f0f0f0", family = "sans"),
    axis.text = element_text(color = "#cccccc", size = 10),
    axis.title = element_text(color = "#ffffff", size = 12, face = "bold"),
    plot.title = element_text(color = "#00ffcc", size = 15, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(color = "#aaaaaa", size = 11, hjust = 0.5),
    legend.background = element_rect(fill = "#1a1a1a", color = "#333333"),
    legend.key = element_rect(fill = "#121212", color = NA),
    legend.text = element_text(color = "#dddddd"),
    legend.title = element_text(color = "#ffffff", face = "bold")
  )


# ==============================================================================
# 13 GGPLOT2 FUNCTIONS & ANALYTICAL EXAMPLES
# ==============================================================================

# 1. geom_bar()
# Analytical Question: How many observation days are recorded for each month?
p1 <- ggplot(df_air, aes(x = Month_Factor, fill = Month_Factor)) +
  geom_bar(color = "#1a1a1a", linewidth = 0.8, alpha = 0.85) +
  scale_fill_manual(values = c("#ff5555", "#ffb86c", "#f1fa8c", "#50fa7b", "#8be9fd")) +
  labs(title = "1. geom_bar()", 
       subtitle = "Observation Days Count per Month",
       x = "Month", y = "Count of Days") +
  theme_dark_custom + theme(legend.position = "none")
print(p1)


# 2. geom_boxplot()
# Analytical Question: What is the monthly distribution and median of maximum temperatures?
p2 <- ggplot(df_air, aes(x = Month_Factor, y = Temp, fill = Month_Factor)) +
  geom_boxplot(color = "#ffffff", outlier.color = "#ff79c6", outlier.size = 2, alpha = 0.7) +
  scale_fill_manual(values = c("#ff5555", "#ffb86c", "#f1fa8c", "#50fa7b", "#8be9fd")) +
  labs(title = "2. geom_boxplot()", 
       subtitle = "Temperature Distribution Across Months",
       x = "Month", y = "Maximum Temperature (°F)") +
  theme_dark_custom + theme(legend.position = "none")
print(p2)


# 3. geom_density()
# Analytical Question: What is the probability density distribution of wind speeds?
p3 <- ggplot(df_air, aes(x = Wind, fill = Month_Factor)) +
  geom_density(alpha = 0.5, color = "#ffffff", linewidth = 0.8) +
  scale_fill_manual(values = c("#ff5555", "#ffb86c", "#f1fa8c", "#50fa7b", "#8be9fd")) +
  labs(title = "3. geom_density()", 
       subtitle = "Probability Density of Wind Speeds",
       x = "Wind Speed (mph)", y = "Density", fill = "Month") +
  theme_dark_custom
print(p3)


# 4. geom_histogram()
# Analytical Question: How are ozone concentration levels distributed across sampled days?
p4 <- ggplot(na.omit(df_air), aes(x = Ozone)) +
  geom_histogram(bins = 15, fill = "#bd93f9", color = "#1a1a1a", linewidth = 0.8, alpha = 0.85) +
  labs(title = "4. geom_histogram()", 
       subtitle = "Frequency Distribution of Ozone Levels",
       x = "Ozone (ppb)", y = "Frequency") +
  theme_dark_custom
print(p4)


# 5. geom_hline()
# Analytical Question: How do daily wind speeds deviate from the overall seasonal mean wind speed?
mean_wind <- mean(df_air$Wind, na.rm = TRUE)
p5 <- ggplot(df_air, aes(x = Day_Index, y = Wind)) +
  geom_line(color = "#8be9fd", linewidth = 0.8) +
  geom_hline(yintercept = mean_wind, color = "#ff5555", linetype = "dashed", linewidth = 1.2) +
  labs(title = "5. geom_hline()", 
       subtitle = paste0("Daily Wind Speed with Mean Reference Line (", round(mean_wind, 1), " mph)"),
       x = "Sequential Day Index", y = "Wind Speed (mph)") +
  theme_dark_custom
print(p5)


# 6. geom_jitter()
# Analytical Question: How do wind speeds relate to temperatures across different months without overplotting?
p6 <- ggplot(df_air, aes(x = Wind, y = Temp, color = Month_Factor)) +
  geom_jitter(width = 0.3, height = 0.3, size = 2.5, alpha = 0.8) +
  scale_color_manual(values = c("#ff5555", "#ffb86c", "#f1fa8c", "#50fa7b", "#8be9fd")) +
  labs(title = "6. geom_jitter()", 
       subtitle = "Wind Speed vs Temperature (Jittered to Prevent Overlapping)",
       x = "Wind Speed (mph)", y = "Temperature (°F)", color = "Month") +
  theme_dark_custom
print(p6)


# 7. geom_line()
# Analytical Question: How do daily maximum temperatures fluctuate sequentially over the summer?
p7 <- ggplot(df_air, aes(x = Day_Index, y = Temp)) +
  geom_line(color = "#ff79c6", linewidth = 1.1) +
  labs(title = "7. geom_line()", 
       subtitle = "Sequential Trend of Daily Temperatures",
       x = "Day Index (May - Sept)", y = "Temperature (°F)") +
  theme_dark_custom
print(p7)


# 8. geom_point()
# Analytical Question: Is there a direct scatter relationship between solar radiation and ozone levels?
p8 <- ggplot(na.omit(df_air), aes(x = Solar.R, y = Ozone)) +
  geom_point(color = "#50fa7b", size = 2.5, alpha = 0.8) +
  labs(title = "8. geom_point()", 
       subtitle = "Solar Radiation vs Ozone Concentration",
       x = "Solar Radiation (lang)", y = "Ozone (ppb)") +
  theme_dark_custom
print(p8)


# 9. geom_rug()
# Analytical Question: What are the marginal frequency distributions alongside the scatter plot?
p9 <- ggplot(na.omit(df_air), aes(x = Temp, y = Ozone)) +
  geom_point(color = "#ffb86c", size = 2, alpha = 0.8) +
  geom_rug(color = "#8be9fd", sides = "bl", alpha = 0.6) +
  labs(title = "9. geom_rug()", 
       subtitle = "Temperature vs Ozone with Marginal Rug Ticks",
       x = "Temperature (°F)", y = "Ozone (ppb)") +
  theme_dark_custom
print(p9)


# 10. geom_smooth()
# Analytical Question: What is the non-linear trend between solar radiation and ozone concentration?
p10 <- ggplot(na.omit(df_air), aes(x = Solar.R, y = Ozone)) +
  geom_point(color = "#6272a4", size = 2, alpha = 0.6) +
  geom_smooth(method = "loess", color = "#ff5555", fill = "#ff5555", alpha = 0.2, linewidth = 1.2) +
  labs(title = "10. geom_smooth()", 
       subtitle = "Solar Radiation vs Ozone with LOESS Trend Line",
       x = "Solar Radiation (lang)", y = "Ozone (ppb)") +
  theme_dark_custom
print(p10)


# 11. geom_text()
# Analytical Question: Which specific day experienced the maximum ozone level, and how can we label it?
max_ozone_row <- df_air %>% filter(Ozone == max(Ozone, na.rm = TRUE))
p11 <- ggplot(na.omit(df_air), aes(x = Temp, y = Ozone)) +
  geom_point(color = "#8be9fd", size = 2.5, alpha = 0.8) +
  geom_text(data = max_ozone_row, 
            aes(label = paste0("Max Ozone: ", Ozone)), 
            vjust = -1, color = "#ff5555", fontface = "bold", size = 4) +
  labs(title = "11. geom_text()", 
       subtitle = "Highlighting Peak Ozone Record with Custom Text Label",
       x = "Temperature (°F)", y = "Ozone (ppb)") +
  theme_dark_custom
print(p11)


# 12. geom_violin()
# Analytical Question: What is the shape of the probability distribution of solar radiation within each month?
p12 <- ggplot(na.omit(df_air), aes(x = Month_Factor, y = Solar.R, fill = Month_Factor)) +
  geom_violin(color = "#ffffff", trim = FALSE, alpha = 0.7, linewidth = 0.8) +
  scale_fill_manual(values = c("#ff5555", "#ffb86c", "#f1fa8c", "#50fa7b", "#8be9fd")) +
  labs(title = "12. geom_violin()", 
       subtitle = "Solar Radiation Distribution Shape by Month",
       x = "Month", y = "Solar Radiation (lang)") +
  theme_dark_custom + theme(legend.position = "none")
print(p12)


# 13. geom_vline()
# Analytical Question: How does a specific threshold temperature compare against the distribution of daily temperatures?
mean_temp <- mean(df_air$Temp, na.rm = TRUE)
p13 <- ggplot(df_air, aes(x = Temp)) +
  geom_histogram(bins = 12, fill = "#ffb86c", color = "#1a1a1a", linewidth = 0.8, alpha = 0.85) +
  geom_vline(xintercept = mean_temp, color = "#8be9fd", linetype = "dashed", linewidth = 1.2) +
  labs(title = "13. geom_vline()", 
       subtitle = paste0("Temperature Histogram with Mean Threshold Line (", round(mean_temp, 1), " °F)"),
       x = "Temperature (°F)", y = "Frequency") +
  theme_dark_custom
print(p13)