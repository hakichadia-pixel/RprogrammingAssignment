# ==============================================================================
# COMPREHENSIVE GUIDE: IMPORTING VARIOUS DATASET FORMATS IN R
# ==============================================================================
# Description: This R script demonstrates how to import different data formats
# into R, specifying the necessary packages/libraries for each format.
# ==============================================================================

# ------------------------------------------------------------------------------
# 0. INSTALL REQUIRED PACKAGES (Uncomment if not already installed)
# ------------------------------------------------------------------------------
install.packages("readr")      # Fast, user-friendly reading of rectangular text files (CSV, TSV, TXT)
install.packages("readxl")     # Excel files (.xls, .xlsx)
install.packages("jsonlite")   # JSON files
install.packages("haven")      # SPSS (.sav), SAS (.sas7bdat), and Stata (.dta) files
install.packages("data.table") # Fast CSV/large data reader (fread)
install.packages("arrow")      # Apache Parquet and Arrow files


# ==============================================================================
# 1. CSV FILES (.csv)
# ==============================================================================
# Libraries: base R, readr, or data.table

# Option A: Base R (No library required)
data_csv_base <- read.csv("r_datasets_package/employees.csv", stringsAsFactors = FALSE)
cat("--- Base R CSV ---\n")
print(head(data_csv_base))

# Option B: readr library (Tidyverse - Recommended for speed and auto-type parsing)
library(readr)
data_csv_readr <- read_csv("r_datasets_package/employees.csv")
cat("\n--- Readr CSV ---\n")
print(data_csv_readr)

# Option C: data.table library (Best for extremely large datasets)
library(data.table)
data_csv_dt <- fread("r_datasets_package/employees.csv")
cat("\n--- data.table CSV ---\n")
print(data_csv_dt)
getwd()
library(readr)  


# ==============================================================================
# 2. TSV / TAB-DELIMITED FILES (.tsv, .txt)
# ==============================================================================
# Library: readr or base R

# Option A: readr
library(readr)
data_tsv <- read_tsv("r_datasets_package/gene_expression.tsv")
cat("\n--- Readr TSV ---\n")
print(data_tsv)

# Option B: Base R
data_tsv_base <- read.delim("r_datasets_package/gene_expression.tsv")


# ==============================================================================
# 3. EXCEL FILES (.xlsx, .xls)
# ==============================================================================
# Library: readxl

library(readxl)

# List sheet names in the workbook
sheets <- excel_sheets("r_datasets_package/sales_data.xlsx")
cat("\n--- Excel Sheets Found ---\n")
print(sheets)

# Read a specific sheet by name or index
data_excel <- read_excel("r_datasets_package/sales_data.xlsx", sheet = "Sales_Q1")
cat("\n--- Excel Data ---\n")
print(data_excel)


# ==============================================================================
# 4. JSON FILES (.json)
# ==============================================================================
# Library: jsonlite

library(jsonlite)

# Import JSON and convert directly to a Data Frame / Tibble
data_json <- fromJSON("r_datasets_package/user_activity.json")
cat("\n--- JSON Data ---\n")
print(data_json)


# ==============================================================================
# 5. TEXT / SPACE-DELIMITED / FIXED WIDTH FILES (.txt)
# ==============================================================================
# Library: readr or base R

# Table/Space delimited
data_txt <- read.table("r_datasets_package/cities_data.txt", header = TRUE)
cat("\n--- Plain Text / Space Delimited ---\n")
print(data_txt)


cat("\n==============================================================================\n")
cat("Import completed successfully! All datasets are ready for analysis in R.\n")
cat("==============================================================================\n")
